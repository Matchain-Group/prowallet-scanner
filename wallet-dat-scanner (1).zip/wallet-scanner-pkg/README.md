# wallet-dat-scanner

Scan a folder of old Bitcoin `wallet.dat` backups and find out which ones
still hold a balance and which are empty — in one command.

## ⚠️ Security first

- These files contain **private keys**. Run this on a machine you trust.
  Never upload actual `wallet.dat` files anywhere online.
- `.gitignore` in this repo already excludes `*.dat` and dump files, so you
  won't accidentally commit your wallets if you push this repo to GitHub.
- Once you find a wallet with a balance, **sweep the funds to a brand-new,
  securely generated wallet** as soon as possible.

## What it does

1. Spins up a throwaway, local Bitcoin Core node (no blockchain sync
   required — it only needs the wallet subsystem).
2. Loads each `wallet.dat`, extracts its addresses via `dumpwallet`.
3. Checks the real on-chain balance of every address via the public
   Blockstream Esplora API.
4. Writes `report.csv`, ranked by balance, so you instantly see which
   wallets are worth keeping and which are empty.

## Requirements

- **Bitcoin Core** (`bitcoind` + `bitcoin-cli`) installed and on your PATH.
  - Download: https://bitcoincore.org/en/download/
  - Version **22.x–25.x recommended**. Some newer Core builds (26+) drop
    support for old Berkeley-DB-format wallets. If `loadwallet` fails on a
    given file, install an older release, or use
    [pywallet.py](https://github.com/jackjack-jj/pywallet) as a fallback —
    it parses the raw wallet.dat format directly.
- **Python 3.8+**

## Setup

```bash
git clone <this-repo-url>
cd wallet-dat-scanner
pip install -r requirements.txt
```

## Usage

```bash
# Put all your wallet.dat files in one folder first, e.g. ./wallets/
# (rename duplicates so each filename is unique, e.g. wallet_01.dat, wallet_02.dat...)

python scan_wallets.py ./wallets --out report.csv
```

You'll be prompted for a passphrase for any wallet that turns out to be
encrypted — press Enter to skip it if you don't know the password.

### Options

| Flag | Description |
|---|---|
| `--out FILE` | Where to write the CSV report (default `report.csv`) |
| `--keep-dumps` | Keep the extracted key dump files instead of deleting them (⚠️ contains private keys) |
| `--delay N` | Seconds between balance API calls, default `0.3` (be polite to the public API) |

## Example output

```
Found 60 wallet.dat file(s).
Starting local, throwaway Bitcoin Core instance (no blockchain sync)...

== wallet_01 ==
  OK
  -> 0.00000000 BTC across 0 funded address(es): EMPTY

== wallet_07 ==
  OK
  -> 0.45210000 BTC across 3 funded address(es): HAS BALANCE
...

Report written to: report.csv

=== Wallets WITH balance ===
  wallet_07: 0.4521 BTC
  wallet_33: 0.0012 BTC
```

`report.csv`:

| wallet | addresses_found | addresses_checked | funded_addresses | total_btc | status |
|---|---|---|---|---|---|
| wallet_07 | 40 | 40 | 3 | 0.45210000 | HAS BALANCE |
| wallet_33 | 8 | 8 | 1 | 0.00120000 | HAS BALANCE |
| wallet_01 | 12 | 12 | 0 | 0.00000000 | EMPTY |

## Testing it before running on your real wallets

If you want to sanity-check the tool works on your machine before pointing
it at your real 60 files, create a fresh test wallet with Bitcoin Core:

```bash
bitcoind -daemon
bitcoin-cli createwallet testwallet
bitcoin-cli -rpcwallet=testwallet getnewaddress
bitcoin-cli -rpcwallet=testwallet dumpwallet /tmp/test_dump.txt
bitcoin-cli stop
```

Then copy that wallet's `wallet.dat` (find it under your Bitcoin Core
datadir, e.g. `~/.bitcoin/wallets/testwallet/wallet.dat`) into a test
folder and run `scan_wallets.py` against it — it should report `EMPTY`
since it has no funds.

## Publishing to GitHub

```bash
git init
git add .
git commit -m "Initial commit: wallet.dat batch scanner"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

The `.gitignore` already keeps your actual wallet files and any generated
reports/dumps out of the repo.

## License

MIT — see `LICENSE`.
